const inputField = document.querySelector("input");
const hElement = document.querySelector("h1");
const currencyCheck = document.querySelector("#currencySelect");
const display = document.querySelector("#display");
class Convert {
  constructor(inputField) {
    this.input = inputField;
    this.currentDollar = 777.48;
    this.currentPound = 977.08;
    this.currentYuen = 106.76;
    this.currentBrics = 400;
    this.dollarToNaira = this.dollarToNaira.bind(this);
    this.poundToNaira = this.poundToNaira.bind(this);
    this.yuenToNaira = this.yuenToNaira.bind(this);
    this.bricsToNaira = this.bricsToNaira.bind(this);
  }

  dollarToNaira() {
    const dollconvert = this.currentDollar * this.input.value;
    const formattedDollars = dollconvert.toLocaleString();
    hElement.innerText = `Live Conversion Update:  $${this.input.value} to naira is N${formattedDollars}`;
    display.innerText = `N${formattedDollars}`;
    if (this.input.value === "") {
      display.innerText = "";
      hElement.innerText = "";
    }
  }

  poundToNaira() {
    const pouConvert = this.currentPound * this.input.value;
    const formattedPounds = pouConvert.toLocaleString();
    hElement.innerText = `Live Conversion Update:  £${this.input.value} pounds to naira is N${formattedPounds}`;
    display.innerText = `N${formattedPounds}`;
    if (this.input.value === "") {
      display.innerText = "";
      hElement.innerText = "";
    }
  }

  yuenToNaira() {
    const yueConvert = this.currentYuen * this.input.value;
    const formattedyuens = yueConvert.toLocaleString();
    hElement.innerText = `Live Conversion Update:  ¥${this.input.value} yuen to naira is N${formattedyuens}`;
    display.innerText = `N${formattedyuens}`;
    if (this.input.value === "") {
      display.innerText = "";
      hElement.innerText = "";
    }
  }

  bricsToNaira() {
    const briConvert = this.currentBrics * this.input.value;
    const formattedBrics = briConvert.toLocaleString();
    hElement.innerText = `Live Conversion Update:  ¢${this.input.value} brics to naira is N${formattedBrics}`;
    display.innerText = `N${formattedBrics}`;
    if (this.input.value === "") {
      display.innerText = "";
      hElement.innerText = "";
    }
  }
}

const checkValue = new Convert(inputField);

inputField.addEventListener("input", function() {
  const selectedCurrency = currencyCheck.value;
  if (selectedCurrency === "dollar") {
    checkValue.dollarToNaira();
  } else if (selectedCurrency === "pound") {
    checkValue.poundToNaira();
  } else if (selectedCurrency === "yuen") {
    checkValue.yuenToNaira();
  } else if (selectedCurrency === "brics") {
    checkValue.bricsToNaira();
  }
});
//SignUp page
const fname = document.getElementById("fname");
const lname = document.getElementById("lname");
const email = document.getElementById("email");
const phoneNumber = document.getElementById("phoneNumber");
const registerButton = document.getElementById("register");
const thanksParagraph = document.getElementById("thanks");
function thankYou(event) {
  event.preventDefault();
  if (fname.value !== "" && lname.value !== "" && email.value !== "" && phoneNumber.value !== "") {
    const checkName = fname.value;
    thanksParagraph.innerHTML = `Thank you for registering ${checkName}`;
  } else {
    thanksParagraph.innerHTML = `Make sure all fields are inputed`;
  }
}

registerButton.addEventListener("click", thankYou);